<?php
/* Redireciona pro diretorio desejado */
header("Location: /SistemaDocumento/login.html");
 
exit;
?>