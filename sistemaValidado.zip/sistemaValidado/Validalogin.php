<?php
session_start();
// conecta ao banco de dados
$dbc= mysqli_connect('localhost', 'DocLab', '33622905', 'DocumentosLab');
$index = 0;
            // obtem os dados de login digitados pelo usuario
            $user_username = $_POST['email'];
            $user_passaword = $_POST['pass'];
           $_SESSION['usuario'] = $user_username;
            // procura o nome e a senha no banco de dados
            $query = "SELECT COUNT(id_users) AS TOTAL FROM users WHERE nome='$user_username' AND senha='$user_passaword'";
            $data= mysqli_query($dbc, $query);
            
            if(mysqli_num_rows($data) == 1){
                header("Location:MenuFuncionario.php");
            }
