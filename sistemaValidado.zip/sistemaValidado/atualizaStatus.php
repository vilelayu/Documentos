<?php
//conecta-se ao banco de dados
try {
    $dbc= mysqli_connect('localhost', 'root', '', 'sistemas_documentos');
            
            // obtem os dados do formulario digitados pelo usuario
           $Usu = $_POST['usuário'];
           $Senha = $_POST['Senha'];
           $Mail  = $_POST['e-mail'];
          
           $query ="call spInsereUser( '$Usu','$Senha','$Mail');";
     
$data= mysqli_query($dbc, $query);

$dbc = null;
header("Location: /SistemaValidado/MenuFuncionario.php");

} catch (Exception $exc) {
    echo $exc->getTraceAsString();
}